(function(){try{var e=typeof window<`u`?window:typeof global<`u`?global:typeof globalThis<`u`?globalThis:typeof self<`u`?self:{};e.SENTRY_RELEASE={id:`ddf6327b697a922a1314b57b85b08e6b64fc071e`}}catch{}})();import{r as e}from"./rolldown-runtime-pQRVpb1T.js";import{o as t,r as n}from"./vendor-sentry-By5C6WoD.js";import{i as r}from"./vendor-sonner-DAz1iJnx.js";import{o as i,t as a}from"./jsx-runtime-D5TiKRhZ.js";import{t as o}from"./compiler-runtime-D0T9bSSV.js";var s=o(),c=e(r(),1),l=a(),u=class extends Error{constructor(e){super(e),this.name=`SentryExampleFrontendError`}},d=()=>[{title:`sentry-example-page`}],f=i(function(){let e=(0,s.c)(21),[r,i]=(0,c.useState)(!1),[a,o]=(0,c.useState)(!0),d,f;e[0]===Symbol.for(`react.memo_cache_sentinel`)?(d=()=>{(async function(){let e=await n();o(e!==`sentry-unreachable`)})()},f=[o],e[0]=d,e[1]=f):(d=e[0],f=e[1]),(0,c.useEffect)(d,f);let m;e[2]===Symbol.for(`react.memo_cache_sentinel`)?(m=(0,l.jsx)(`div`,{className:`flex-spacer`}),e[2]=m):m=e[2];let h,g;e[3]===Symbol.for(`react.memo_cache_sentinel`)?(h=(0,l.jsx)(`svg`,{height:`40`,width:`40`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`,children:(0,l.jsx)(`path`,{d:`M21.85 2.995a3.698 3.698 0 0 1 1.353 1.354l16.303 28.278a3.703 3.703 0 0 1-1.354 5.053 3.694 3.694 0 0 1-1.848.496h-3.828a31.149 31.149 0 0 0 0-3.09h3.815a.61.61 0 0 0 .537-.917L20.523 5.893a.61.61 0 0 0-1.057 0l-3.739 6.494a28.948 28.948 0 0 1 9.63 10.453 28.988 28.988 0 0 1 3.499 13.78v1.542h-9.852v-1.544a19.106 19.106 0 0 0-2.182-8.85 19.08 19.08 0 0 0-6.032-6.829l-1.85 3.208a15.377 15.377 0 0 1 6.382 12.484v1.542H3.696A3.694 3.694 0 0 1 0 34.473c0-.648.17-1.286.494-1.849l2.33-4.074a8.562 8.562 0 0 1 2.689 1.536L3.158 34.17a.611.611 0 0 0 .538.917h8.448a12.481 12.481 0 0 0-6.037-9.09l-1.344-.772 4.908-8.545 1.344.77a22.16 22.16 0 0 1 7.705 7.444 22.193 22.193 0 0 1 3.316 10.193h3.699a25.892 25.892 0 0 0-3.811-12.033 25.856 25.856 0 0 0-9.046-8.796l-1.344-.772 5.269-9.136a3.698 3.698 0 0 1 3.2-1.849c.648 0 1.285.17 1.847.495Z`,fill:`currentcolor`})}),g=(0,l.jsx)(`h1`,{children:`sentry-example-page`}),e[3]=h,e[4]=g):(h=e[3],g=e[4]);let _;e[5]===Symbol.for(`react.memo_cache_sentinel`)?(_=(0,l.jsx)(`a`,{target:`_blank`,rel:`noreferrer`,href:`https://matthew-balaam.sentry.io/issues/?project=4510936655265872`,children:`Issues Page`}),e[5]=_):_=e[5];let v;e[6]===Symbol.for(`react.memo_cache_sentinel`)?(v=(0,l.jsxs)(`p`,{className:`description`,children:[`Click the button below, and view the sample error on the Sentry`,` `,_,`. For more details about setting up Sentry,`,` `,(0,l.jsx)(`a`,{target:`_blank`,rel:`noreferrer`,href:`https://docs.sentry.io/platforms/javascript/guides/react-router/`,children:`read our docs`}),`.`]}),e[6]=v):v=e[6];let y;e[7]===Symbol.for(`react.memo_cache_sentinel`)?(y=async()=>{throw await t({name:`Example Frontend Span`,op:`test`},async()=>{(await fetch(`/api/sentry-example-api`)).ok||i(!0)}),new u(`This error is raised on the frontend of the example page.`)},e[7]=y):y=e[7];let b=!a,x;e[8]===Symbol.for(`react.memo_cache_sentinel`)?(x=(0,l.jsx)(`span`,{children:`Throw Sample Error`}),e[8]=x):x=e[8];let S;e[9]===b?S=e[10]:(S=(0,l.jsx)(`button`,{type:`button`,onClick:y,disabled:b,children:x}),e[9]=b,e[10]=S);let C;e[11]!==r||e[12]!==a?(C=r?(0,l.jsx)(`p`,{className:`success`,children:`Sample error was sent to Sentry.`}):a?(0,l.jsx)(`div`,{className:`success_placeholder`}):(0,l.jsx)(`div`,{className:`connectivity-error`,children:(0,l.jsx)(`p`,{children:`It looks like network requests to Sentry are being blocked, which will prevent errors from being captured. Try disabling your ad-blocker to complete the test.`})}),e[11]=r,e[12]=a,e[13]=C):C=e[13];let w;e[14]===Symbol.for(`react.memo_cache_sentinel`)?(w=(0,l.jsx)(`div`,{className:`flex-spacer`}),e[14]=w):w=e[14];let T;e[15]!==S||e[16]!==C?(T=(0,l.jsxs)(`main`,{children:[m,h,g,v,S,C,w]}),e[15]=S,e[16]=C,e[17]=T):T=e[17];let E;e[18]===Symbol.for(`react.memo_cache_sentinel`)?(E=(0,l.jsx)(`style`,{dangerouslySetInnerHTML:{__html:p}}),e[18]=E):E=e[18];let D;return e[19]===T?D=e[20]:(D=(0,l.jsxs)(`div`,{children:[T,E]}),e[19]=T,e[20]=D),D}),p=`
  main {
    display: flex;
    min-height: 100vh;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 16px;
    padding: 16px;
    font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", sans-serif;
  }

  h1 {
    padding: 0px 4px;
    border-radius: 4px;
    background-color: rgba(24, 20, 35, 0.03);
    font-family: monospace;
    font-size: 20px;
    line-height: 1.2;
  }

  p {
    margin: 0;
    font-size: 20px;
  }

  a {
    color: #6341F0;
    text-decoration: underline;
    cursor: pointer;

    @media (prefers-color-scheme: dark) {
      color: #B3A1FF;
    }
  }

  button {
    border-radius: 8px;
    color: white;
    cursor: pointer;
    background-color: #553DB8;
    border: none;
    padding: 0;
    margin-top: 4px;

    & > span {
      display: inline-block;
      padding: 12px 16px;
      border-radius: inherit;
      font-size: 20px;
      font-weight: bold;
      line-height: 1;
      background-color: #7553FF;
      border: 1px solid #553DB8;
      transform: translateY(-4px);
    }

    &:hover > span {
      transform: translateY(-8px);
    }

    &:active > span {
      transform: translateY(0);
    }

    &:disabled {
      cursor: not-allowed;
      opacity: 0.6;

      & > span {
        transform: translateY(0);
        border: none;
      }
    }
  }

  .description {
    text-align: center;
    color: #6E6C75;
    max-width: 500px;
    line-height: 1.5;
    font-size: 20px;

    @media (prefers-color-scheme: dark) {
      color: #A49FB5;
    }
  }

  .flex-spacer {
    flex: 1;
  }

  .success {
    padding: 12px 16px;
    border-radius: 8px;
    font-size: 20px;
    line-height: 1;
    background-color: #00F261;
    border: 1px solid #00BF4D;
    color: #181423;
  }

  .success_placeholder {
    height: 46px;
  }

  .connectivity-error {
    padding: 12px 16px;
    background-color: #E50045;
    border-radius: 8px;
    width: 500px;
    color: #FFFFFF;
    border: 1px solid #A80033;
    text-align: center;
    margin: 0;
  }

  .connectivity-error a {
    color: #FFFFFF;
    text-decoration: underline;
  }
`;export{f as default,d as meta};